
/*
 * define here type ImageSlider
 */
